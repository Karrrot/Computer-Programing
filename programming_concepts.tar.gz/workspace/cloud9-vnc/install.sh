#!/bin/bash

cd /home/ubuntu

sudo apt-get install supervisor xvfb fluxbox x11vnc
git clone git://github.com/kanaka/noVNC
