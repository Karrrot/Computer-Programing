public class Excerpt{

//“I pledge my Honor that I have not cheated, and will not cheat, on this assignment” Karan Limbachia

    public static void main(String[] args){
        System.out.print("   \"Dude, I can see in your mind's eye, that you put"
            + "\nhalf-and-half into one of those coffees, in an attempt to"
            + "\nmake me break Vegan-edge. I'll take the one with soy.\""
            + "\n " //A Space in the Excerpt
            + "\n    Todd levitates the other cup from Scott's hand and "
            + "\nbrings it to his own.\"Thanks, tool\", he says, sipping the "
            + "\ncoffee."
            + "\n" //A Space in the Excerpt
            + "\n   \"Actually, muchacho,I poured the soy in this cup, but "
            + "\nI thought real hard about pouring it in that cup. You know,"
            + "\nin my mind's eye' or whatever.\" Scott responds, sipping his own coffee."
            + "\n" //A Space in the Excerpt
            + "\n   \"What are you talking about? \""
            + "\n" //A Space in the Excerpt
            + "\n   \"You just drank half-and-half, baby. \""
            );
    }
} 

/*
"Dude, I can see in your mind's eye, that you put
half-and-half into one of those coffees, in an attempt to
make me break Vegan-edge. I'll take the one with soy."

Todd levitates the other cup from Scott's hand and 
brings it to his own."Thanks, tool", he says, sipping the 
coffee.

"Actually,muchacho,I poured the soy in this cup, but 
I thought real hard about pouring it in that cup. You know,
in my mind's eye' or whatever." Scott responds, sipping his own coffee.

"What are you talking about?"
"You just drank half-and-half, baby."
*/
