public class CorrectCode {

//*   “I pledge my Honor that I have not cheated, and will not cheat, on this assignment” Karan Limbachia

    public static void main(String[] args){
        System.out.print("This program is riddled");
        System.out.println(" with syntax errors.");
        System.out.print("But if you can output this message, ");
        System.out.println("then you have corrected them all!");
    }
}   